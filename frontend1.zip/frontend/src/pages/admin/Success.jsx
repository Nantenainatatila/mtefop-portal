import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../../api/axios";

function Success() {
    const [appDeploi, setAppDeploi] = useState([]);
    const [chargement, setChargement] = useState(true);

    const chargerAppSucces = async() => {
        try {
            setChargement(true);
            const response = await api.get("/success_failed/success");
            setAppDeploi(response.data);

        } catch (err) {
            console.log("Erreur de recuperation de app succes frontend");
        } finally {
            setChargement(false);
        }
    };

    useEffect(() => { chargerAppSucces() } , []);
    if (chargement) {
        return <p>Chargement en cours...</p>;
    }
    return(
        <div>
            <h3>Application en succès</h3>
            <table>
                <thead>
                    <tr>
                        
                        <th>Admin</th>
                        <th>Nom </th>
                        <th>Nom de bouton</th>
                        <th>ID DEPLOI</th>
                        <th>url_publique</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {appDeploi.length > 0 
                        ? 
                        appDeploi.map((app) => (
                            <tr key={app.id_deploie}>
        
                                <td>{app.nom_admin}</td>
                                <td>{app.nom_app }</td>
                                <td>{app.nom_bouton_app}</td>
                               <td>{app.id_deploie}</td>
                                <td><Link to={app.url_publique_deploie}>{app.url_publique_deploie}</Link></td>
                                <td>
                                    <Link to={`/admin/application/${app.id_app}`}>Plus des détails</Link>
                                </td>
                            </tr>
                        ))
                        
                        : <td colSpan={4}>Aucun deploiements succès</td>
                    }
                </tbody>
            </table>
            
        </div>
    )
}
export default Success;