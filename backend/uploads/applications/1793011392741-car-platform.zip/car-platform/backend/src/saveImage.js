
// Enregistre une image dans la table "images" et renvoie son adresse (ex : /api/images/12).
// ✨ Toute image est automatiquement convertie en WebP (plus légère) et réduite à 1200 px max.
// Si aucun fichier n'est envoyé, renvoie null (l'image est facultative).
const sharp = require('sharp');
const pool = require('./db');

// Convertit n'importe quelle image (jpg, png, gif...) en WebP
async function convertirEnWebp(buffer) {
  return sharp(buffer)
    .rotate() // remet la photo dans le bon sens (les photos de téléphone sont parfois tournées)
    .resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true }) // 1200 px max
    .webp({ quality: 80 }) // qualité 80 : très bonne image, fichier léger
    .toBuffer();
}

async function saveImage(file) {
  if (!file) return null;

  let data;
  try {
    data = await convertirEnWebp(file.buffer);
  } catch (e) {
    console.error('Conversion WebP impossible :', e.message);
    throw new Error('Image invalide');
  }

  const result = await pool.query('INSERT INTO images (data, mimetype) VALUES ($1, $2) RETURNING id', [
    data,
    'image/webp',
  ]);
  return '/api/images/' + result.rows[0].id;
}

module.exports = saveImage;