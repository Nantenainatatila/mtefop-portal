const r = require('express').Router();
const bcrypt = require('bcryptjs'); const jwt = require('jsonwebtoken');
const db = require('../db'); const { auth } = require('../middleware/auth');
r.post('/login', async (req, res) => {
  const { email, mot_de_passe } = req.body;
  const [[u]] = await db.query('SELECT * FROM utilisateurs WHERE email=? AND actif=1', [email]);
  if (!u || !(await bcrypt.compare(mot_de_passe || '', u.mot_de_passe)))
    return res.status(401).json({ message: 'Email ou mot de passe incorrect' });
  const user = { id: u.id, nom: u.nom, prenom: u.prenom, email: u.email, role: u.role, service_id: u.service_id };
  res.json({ token: jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '8h' }), user });
});
r.get('/me', auth, (req, res) => res.json(req.user));
module.exports = r;
