const r = require('express').Router();
const multer = require('multer'); const path = require('path');
const db = require('../db'); const { auth, role } = require('../middleware/auth');
const upload = multer({ storage: multer.diskStorage({
  destination: path.join(__dirname, '../../uploads'),
  filename: (q, f, cb) => cb(null, Date.now() + '-' + f.originalname.replace(/[^\w.-]/g, '_')) }),
  limits: { fileSize: 10 * 1024 * 1024 } });

const SELECT = `SELECT d.*, t.libelle type_libelle, s.nom service_nom, s.code service_code,
  CONCAT(u.nom,' ',IFNULL(u.prenom,'')) cree_par_nom FROM dossiers d
  LEFT JOIN types_dossier t ON t.id=d.type_id LEFT JOIN services s ON s.id=d.service_actuel_id
  LEFT JOIN utilisateurs u ON u.id=d.cree_par`;

const histo = (id) => db.query(`SELECT h.*, ss.nom source_nom, sd.nom dest_nom,
  CONCAT(u.nom,' ',IFNULL(u.prenom,'')) utilisateur_nom FROM historique h
  LEFT JOIN services ss ON ss.id=h.service_source_id LEFT JOIN services sd ON sd.id=h.service_dest_id
  LEFT JOIN utilisateurs u ON u.id=h.utilisateur_id WHERE h.dossier_id=? ORDER BY h.date_action DESC, h.id DESC`, [id]);

// Suivi public par numéro
r.get('/suivi/:numero', async (req, res) => {
  const [[d]] = await db.query(`SELECT d.id,d.numero,d.objet,d.statut,d.date_depot,d.updated_at,t.libelle type_libelle,s.nom service_nom
    FROM dossiers d LEFT JOIN types_dossier t ON t.id=d.type_id LEFT JOIN services s ON s.id=d.service_actuel_id WHERE d.numero=?`, [req.params.numero]);
  if (!d) return res.status(404).json({ message: 'Aucun dossier trouvé avec ce numéro' });
  const [h] = await histo(d.id);
  delete d.id;
  res.json({ ...d, historique: h.map(({ action, statut, source_nom, dest_nom, date_action }) => ({ action, statut, source_nom, dest_nom, date_action })) });
});

r.use(auth);

r.get('/', async (req, res) => {
  const { q, statut, service_id, type_id } = req.query; const w = []; const p = [];
  if (q) { w.push('(d.numero LIKE ? OR d.objet LIKE ? OR d.demandeur_nom LIKE ? OR d.demandeur_matricule LIKE ?)'); p.push(...Array(4).fill(`%${q}%`)); }
  if (statut) { w.push('d.statut=?'); p.push(statut); }
  if (service_id) { w.push('d.service_actuel_id=?'); p.push(service_id); }
  if (type_id) { w.push('d.type_id=?'); p.push(type_id); }
  const [rows] = await db.query(`${SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY d.created_at DESC LIMIT 500`, p);
  res.json(rows);
});

r.get('/:id', async (req, res) => {
  const [[d]] = await db.query(`${SELECT} WHERE d.id=?`, [req.params.id]);
  if (!d) return res.status(404).json({ message: 'Dossier introuvable' });
  const [h] = await histo(d.id);
  const [pj] = await db.query('SELECT * FROM pieces_jointes WHERE dossier_id=? ORDER BY id DESC', [d.id]);
  res.json({ ...d, historique: h, pieces: pj });
});

r.post('/', role('admin', 'agent'), async (req, res) => {
  const b = req.body; const an = new Date().getFullYear();
  const [[{ n }]] = await db.query('SELECT COUNT(*)+1 n FROM dossiers WHERE YEAR(created_at)=?', [an]);
  const numero = `MTEFOP-${an}-${String(n).padStart(5, '0')}`;
  const [[t]] = await db.query('SELECT delai_jours FROM types_dossier WHERE id=?', [b.type_id || 0]);
  const depot = b.date_depot || new Date().toISOString().slice(0, 10);
  const ech = new Date(depot); ech.setDate(ech.getDate() + (t ? t.delai_jours : 30));
  const service = b.service_actuel_id || req.user.service_id || null;
  const [ins] = await db.query(`INSERT INTO dossiers (numero,objet,type_id,demandeur_nom,demandeur_matricule,demandeur_cin,
    demandeur_telephone,demandeur_email,description,priorite,service_actuel_id,cree_par,date_depot,date_echeance)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [numero, b.objet, b.type_id || null, b.demandeur_nom, b.demandeur_matricule,
    b.demandeur_cin, b.demandeur_telephone, b.demandeur_email, b.description, b.priorite || 'normale', service,
    req.user.id, depot, ech.toISOString().slice(0, 10)]);
  await db.query(`INSERT INTO historique (dossier_id,action,service_dest_id,statut,commentaire,utilisateur_id)
    VALUES (?,'Enregistrement',?,'recu','Dossier reçu et enregistré',?)`, [ins.insertId, service, req.user.id]);
  res.status(201).json({ id: ins.insertId, numero });
});

r.put('/:id', role('admin', 'agent'), async (req, res) => {
  const b = req.body;
  await db.query(`UPDATE dossiers SET objet=?,type_id=?,demandeur_nom=?,demandeur_matricule=?,demandeur_cin=?,
    demandeur_telephone=?,demandeur_email=?,description=?,priorite=? WHERE id=?`, [b.objet, b.type_id || null, b.demandeur_nom,
    b.demandeur_matricule, b.demandeur_cin, b.demandeur_telephone, b.demandeur_email, b.description, b.priorite, req.params.id]);
  await db.query(`INSERT INTO historique (dossier_id,action,commentaire,utilisateur_id) VALUES (?,'Modification','Informations mises à jour',?)`, [req.params.id, req.user.id]);
  res.json({ ok: true });
});

r.post('/:id/transferer', role('admin', 'agent'), async (req, res) => {
  const { service_dest_id, commentaire } = req.body;
  const [[d]] = await db.query('SELECT service_actuel_id FROM dossiers WHERE id=?', [req.params.id]);
  if (!d) return res.status(404).json({ message: 'Dossier introuvable' });
  await db.query(`UPDATE dossiers SET service_actuel_id=?, statut='en_cours' WHERE id=?`, [service_dest_id, req.params.id]);
  await db.query(`INSERT INTO historique (dossier_id,action,service_source_id,service_dest_id,statut,commentaire,utilisateur_id)
    VALUES (?,'Transfert',?,?,'en_cours',?,?)`, [req.params.id, d.service_actuel_id, service_dest_id, commentaire, req.user.id]);
  res.json({ ok: true });
});

r.post('/:id/statut', role('admin', 'agent'), async (req, res) => {
  const { statut, commentaire } = req.body;
  await db.query('UPDATE dossiers SET statut=? WHERE id=?', [statut, req.params.id]);
  await db.query(`INSERT INTO historique (dossier_id,action,statut,commentaire,utilisateur_id) VALUES (?,'Changement de statut',?,?,?)`,
    [req.params.id, statut, commentaire, req.user.id]);
  res.json({ ok: true });
});

r.post('/:id/pieces', role('admin', 'agent'), upload.single('fichier'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier' });
  await db.query('INSERT INTO pieces_jointes (dossier_id,nom_original,fichier,taille,ajoute_par) VALUES (?,?,?,?,?)',
    [req.params.id, req.file.originalname, req.file.filename, req.file.size, req.user.id]);
  res.status(201).json({ ok: true });
});

r.delete('/:id', role('admin'), async (req, res) => {
  await db.query('DELETE FROM dossiers WHERE id=?', [req.params.id]); res.json({ ok: true });
});
module.exports = r;
