const r = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db'); const { auth, role } = require('../middleware/auth');
r.use(auth);
r.get('/services', async (q, res) => res.json((await db.query('SELECT * FROM services ORDER BY nom'))[0]));
r.post('/services', role('admin'), async (q, res) => {
  await db.query('INSERT INTO services (code,nom,description) VALUES (?,?,?)', [q.body.code, q.body.nom, q.body.description]);
  res.status(201).json({ ok: true });
});
r.delete('/services/:id', role('admin'), async (q, res) => { await db.query('DELETE FROM services WHERE id=?', [q.params.id]); res.json({ ok: true }); });
r.get('/types', async (q, res) => res.json((await db.query('SELECT * FROM types_dossier ORDER BY libelle'))[0]));
r.post('/types', role('admin'), async (q, res) => {
  await db.query('INSERT INTO types_dossier (libelle,delai_jours) VALUES (?,?)', [q.body.libelle, q.body.delai_jours || 30]);
  res.status(201).json({ ok: true });
});
r.get('/utilisateurs', role('admin'), async (q, res) => res.json((await db.query(
  `SELECT u.id,u.matricule,u.nom,u.prenom,u.email,u.role,u.actif,s.nom service_nom FROM utilisateurs u
   LEFT JOIN services s ON s.id=u.service_id ORDER BY u.nom`))[0]));
r.post('/utilisateurs', role('admin'), async (q, res) => {
  const b = q.body; const hash = await bcrypt.hash(b.mot_de_passe, 10);
  try {
    await db.query('INSERT INTO utilisateurs (matricule,nom,prenom,email,mot_de_passe,role,service_id) VALUES (?,?,?,?,?,?,?)',
      [b.matricule, b.nom, b.prenom, b.email, hash, b.role, b.service_id || null]);
    res.status(201).json({ ok: true });
  } catch (e) { res.status(400).json({ message: 'Email ou matricule déjà utilisé' }); }
});
r.patch('/utilisateurs/:id/actif', role('admin'), async (q, res) => {
  await db.query('UPDATE utilisateurs SET actif=1-actif WHERE id=?', [q.params.id]); res.json({ ok: true });
});
r.get('/stats', async (q, res) => {
  const [[tot]] = await db.query(`SELECT COUNT(*) total, SUM(statut IN ('recu','en_cours','en_attente')) en_traitement,
    SUM(statut='valide') valides, SUM(statut='rejete') rejetes,
    SUM(date_echeance < CURDATE() AND statut NOT IN ('valide','rejete','cloture')) en_retard FROM dossiers`);
  const [parStatut] = await db.query('SELECT statut, COUNT(*) n FROM dossiers GROUP BY statut');
  const [parService] = await db.query(`SELECT s.nom, COUNT(d.id) n FROM services s LEFT JOIN dossiers d ON d.service_actuel_id=s.id GROUP BY s.id ORDER BY n DESC`);
  const [recents] = await db.query(`SELECT d.id,d.numero,d.objet,d.statut,d.demandeur_nom,s.nom service_nom FROM dossiers d
    LEFT JOIN services s ON s.id=d.service_actuel_id ORDER BY d.updated_at DESC LIMIT 6`);
  res.json({ ...tot, parStatut, parService, recents });
});
module.exports = r;
