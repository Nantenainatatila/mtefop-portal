const bcrypt = require('bcryptjs');
const db = require('./db');
(async () => {
  const hash = await bcrypt.hash('Admin@123', 10);
  await db.query(`INSERT IGNORE INTO utilisateurs (matricule,nom,prenom,email,mot_de_passe,role,service_id)
    VALUES ('ADM001','Administrateur','Système','admin@mtefop.gov.mg',?,'admin',6)`, [hash]);
  const h2 = await bcrypt.hash('Agent@123', 10);
  await db.query(`INSERT IGNORE INTO utilisateurs (matricule,nom,prenom,email,mot_de_passe,role,service_id)
    VALUES ('AGT001','Rakoto','Jean','agent@mtefop.gov.mg',?,'agent',1)`, [h2]);
  console.log('Comptes créés : admin@mtefop.gov.mg / Admin@123 ; agent@mtefop.gov.mg / Agent@123');
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
