-- ============================================================
-- BASE : GESTION DE SUIVI DES DOSSIERS MTEFOP
-- MOTEUR : PostgreSQL
-- IMPORTANT : la base est créée par le service Docker
-- ============================================================

-- ============================================================
-- 1. TABLE SERVICES
-- ============================================================

CREATE TABLE services (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    nom VARCHAR(150) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 2. TABLE UTILISATEURS
-- ============================================================

CREATE TABLE utilisateurs (
    id SERIAL PRIMARY KEY,
    matricule VARCHAR(30) UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100),
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,

    role VARCHAR(20) DEFAULT 'agent'
        CHECK (role IN ('admin', 'agent', 'consultation')),

    service_id INTEGER,

    actif BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_utilisateurs_service
        FOREIGN KEY (service_id)
        REFERENCES services(id)
        ON DELETE SET NULL
);
INSERT INTO utilisateurs (
    matricule, 
    nom, 
    prenom, 
    email, 
    mot_de_passe
    ) 
    VALUES(1234,'Nantenaina','Tatila', 'devnantenaina@gmail.com','4515');

-- ============================================================
-- 3. TABLE TYPES_DOSSIER
-- ============================================================

CREATE TABLE types_dossier (
    id SERIAL PRIMARY KEY,
    libelle VARCHAR(150) NOT NULL,
    delai_jours INTEGER DEFAULT 30
);

-- ============================================================
-- 4. TABLE DOSSIERS
-- ============================================================

CREATE TABLE dossiers (
    id SERIAL PRIMARY KEY,
    numero VARCHAR(30) NOT NULL UNIQUE,
    objet VARCHAR(255) NOT NULL,

    type_id INTEGER,

    demandeur_nom VARCHAR(150) NOT NULL,
    demandeur_matricule VARCHAR(30),
    demandeur_cin VARCHAR(20),
    demandeur_telephone VARCHAR(30),
    demandeur_email VARCHAR(150),

    description TEXT,

    priorite VARCHAR(20) DEFAULT 'normale'
        CHECK (
            priorite IN ('normale', 'urgente', 'tres_urgente')
        ),

    statut VARCHAR(20) DEFAULT 'recu'
        CHECK (
            statut IN (
                'recu',
                'en_cours',
                'en_attente',
                'valide',
                'rejete',
                'cloture'
            )
        ),

    service_actuel_id INTEGER,
    cree_par INTEGER,

    date_depot DATE NOT NULL,
    date_echeance DATE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_dossiers_type
        FOREIGN KEY (type_id)
        REFERENCES types_dossier(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_dossiers_service
        FOREIGN KEY (service_actuel_id)
        REFERENCES services(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_dossiers_utilisateur
        FOREIGN KEY (cree_par)
        REFERENCES utilisateurs(id)
        ON DELETE SET NULL
);

-- ============================================================
-- 5. TABLE HISTORIQUE
-- ============================================================

CREATE TABLE historique (
    id SERIAL PRIMARY KEY,

    dossier_id INTEGER NOT NULL,
    action VARCHAR(50) NOT NULL,

    service_source_id INTEGER,
    service_dest_id INTEGER,

    statut VARCHAR(30),
    commentaire TEXT,

    utilisateur_id INTEGER,

    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_historique_dossier
        FOREIGN KEY (dossier_id)
        REFERENCES dossiers(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_historique_service_source
        FOREIGN KEY (service_source_id)
        REFERENCES services(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_historique_service_dest
        FOREIGN KEY (service_dest_id)
        REFERENCES services(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_historique_utilisateur
        FOREIGN KEY (utilisateur_id)
        REFERENCES utilisateurs(id)
        ON DELETE SET NULL
);

-- ============================================================
-- 6. TABLE PIECES_JOINTES
-- ============================================================

CREATE TABLE pieces_jointes (
    id SERIAL PRIMARY KEY,

    dossier_id INTEGER NOT NULL,

    nom_original VARCHAR(255) NOT NULL,
    fichier VARCHAR(255) NOT NULL,

    taille INTEGER,
    ajoute_par INTEGER,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_pieces_jointes_dossier
        FOREIGN KEY (dossier_id)
        REFERENCES dossiers(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_pieces_jointes_utilisateur
        FOREIGN KEY (ajoute_par)
        REFERENCES utilisateurs(id)
        ON DELETE SET NULL
);

-- ============================================================
-- 7. INDEX
-- ============================================================

CREATE INDEX idx_dossiers_statut
    ON dossiers(statut);

CREATE INDEX idx_dossiers_service
    ON dossiers(service_actuel_id);

-- ============================================================
-- 8. MISE À JOUR AUTOMATIQUE DE updated_at
-- PostgreSQL ne prend pas en charge
-- ON UPDATE CURRENT_TIMESTAMP comme MySQL.
-- ============================================================

CREATE OR REPLACE FUNCTION mettre_a_jour_date_modification()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_dossiers_updated_at
BEFORE UPDATE ON dossiers
FOR EACH ROW
EXECUTE FUNCTION mettre_a_jour_date_modification();

-- ============================================================
-- 9. DONNÉES INITIALES : SERVICES
-- ============================================================

INSERT INTO services (code, nom, description) VALUES
('BCO', 'Bureau du Courrier',
 'Réception et enregistrement des dossiers'),

('DRH', 'Direction des Ressources Humaines',
 'Gestion des carrières'),

('DGFP', 'Direction Générale de la Fonction Publique',
 'Actes administratifs des agents de l''État'),

('DPE', 'Direction de la Promotion de l''Emploi',
 'Emploi et insertion'),

('DTRA', 'Direction du Travail',
 'Relations professionnelles'),

('DSI', 'Direction des Systèmes d''Information',
 'Informatique'),

('SG', 'Secrétariat Général',
 'Validation et signature');

-- ============================================================
-- 10. DONNÉES INITIALES : TYPES DE DOSSIER
-- ============================================================

INSERT INTO types_dossier (libelle, delai_jours) VALUES
('Avancement / reclassement', 60),
('Intégration / titularisation', 90),
('Mise à la retraite', 90),
('Congé / disponibilité', 15),
('Mutation / affectation', 30),
('Attestation / certificat', 7),
('Recrutement', 60),
('Réclamation', 30);


