import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { Logo } from '../components/Layout';
export default function Login() {
  const [f, setF] = useState({ email: '', mot_de_passe: '' }); const [err, setErr] = useState(''); const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    try { const { data } = await api.post('/auth/login', f); localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user)); nav('/'); }
    catch (e) { setErr(errMsg(e)); }
  };
  return (
    <div className="login-page">
      <div className="login-side"><h1>Gestion et suivi des dossiers en ligne</h1>
        <p>Plateforme du Ministère du Travail, de l'Emploi et de la Fonction Publique – Madagascar.</p>
        <Link to="/suivi" className="btn light">Suivre mon dossier sans connexion</Link></div>
      <form className="login-card" onSubmit={submit}>
        <Logo /><h2>Connexion agent</h2>
        {err && <div className="alert">{err}</div>}
        <label>Email<input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
        <label>Mot de passe<input type="password" required value={f.mot_de_passe} onChange={(e) => setF({ ...f, mot_de_passe: e.target.value })} /></label>
        <button className="btn primary full">Se connecter</button>
      </form>
    </div>
  );
}
