import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { STATUTS } from '../api';
import { Badge } from '../components/Layout';
export default function Dashboard() {
  const [s, setS] = useState(null);
  useEffect(() => { api.get('/stats').then((r) => setS(r.data)); }, []);
  if (!s) return <p>Chargement…</p>;
  const max = Math.max(1, ...s.parService.map((x) => x.n));
  return (<>
    <h1>Tableau de bord</h1>
    <div className="stats">
      {[['Total dossiers', s.total], ['En traitement', s.en_traitement], ['Validés', s.valides], ['Rejetés', s.rejetes], ['En retard', s.en_retard]].map(([l, v]) =>
        <div className="stat" key={l}><span>{l}</span><strong>{v || 0}</strong></div>)}
    </div>
    <div className="grid2">
      <div className="card"><h3>Dossiers par service</h3>
        {s.parService.map((x) => <div className="bar" key={x.nom}><span>{x.nom}</span><div><i style={{ width: `${(x.n / max) * 100}%` }} /></div><b>{x.n}</b></div>)}
      </div>
      <div className="card"><h3>Par statut</h3>
        {s.parStatut.map((x) => <div className="row-between" key={x.statut}><Badge s={x.statut} /><b>{x.n}</b></div>)}
        {!s.parStatut.length && <p className="muted">Aucun dossier</p>}
      </div>
    </div>
    <div className="card"><h3>Activité récente</h3>
      <table><thead><tr><th>Numéro</th><th>Objet</th><th>Demandeur</th><th>Service</th><th>Statut</th></tr></thead>
        <tbody>{s.recents.map((d) => <tr key={d.id}><td><Link to={`/dossiers/${d.id}`}>{d.numero}</Link></td><td>{d.objet}</td><td>{d.demandeur_nom}</td><td>{d.service_nom}</td><td><Badge s={d.statut} /></td></tr>)}</tbody></table>
    </div>
  </>);
}
