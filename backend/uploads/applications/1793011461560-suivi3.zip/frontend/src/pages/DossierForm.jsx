import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api, { errMsg, PRIORITES } from '../api';
const vide = { objet: '', type_id: '', demandeur_nom: '', demandeur_matricule: '', demandeur_cin: '', demandeur_telephone: '', demandeur_email: '', description: '', priorite: 'normale', service_actuel_id: '', date_depot: new Date().toISOString().slice(0, 10) };
export default function DossierForm() {
  const { id } = useParams(); const nav = useNavigate();
  const [f, setF] = useState(vide); const [types, setTypes] = useState([]); const [services, setServices] = useState([]); const [err, setErr] = useState('');
  useEffect(() => {
    api.get('/types').then((r) => setTypes(r.data)); api.get('/services').then((r) => setServices(r.data));
    if (id) api.get(`/dossiers/${id}`).then((r) => setF({ ...vide, ...Object.fromEntries(Object.entries(r.data).map(([k, v]) => [k, v ?? ''])) }));
  }, [id]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    try { if (id) { await api.put(`/dossiers/${id}`, f); nav(`/dossiers/${id}`); } else { const { data } = await api.post('/dossiers', f); nav(`/dossiers/${data.id}`); } }
    catch (e) { setErr(errMsg(e)); }
  };
  return (<>
    <h1>{id ? 'Modifier le dossier' : 'Enregistrer un nouveau dossier'}</h1>
    <form className="card form" onSubmit={submit}>
      {err && <div className="alert">{err}</div>}
      <h3>Dossier</h3>
      <div className="fgrid">
        <label className="span2">Objet *<input required value={f.objet} onChange={set('objet')} /></label>
        <label>Type de dossier<select value={f.type_id} onChange={set('type_id')}><option value="">—</option>{types.map((t) => <option key={t.id} value={t.id}>{t.libelle}</option>)}</select></label>
        <label>Priorité<select value={f.priorite} onChange={set('priorite')}>{Object.entries(PRIORITES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        {!id && <><label>Date de dépôt<input type="date" value={f.date_depot} onChange={set('date_depot')} /></label>
          <label>Service destinataire<select value={f.service_actuel_id} onChange={set('service_actuel_id')}><option value="">Mon service</option>{services.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}</select></label></>}
        <label className="span2">Description<textarea rows="3" value={f.description} onChange={set('description')} /></label>
      </div>
      <h3>Demandeur</h3>
      <div className="fgrid">
        <label>Nom et prénoms *<input required value={f.demandeur_nom} onChange={set('demandeur_nom')} /></label>
        <label>Matricule<input value={f.demandeur_matricule} onChange={set('demandeur_matricule')} /></label>
        <label>CIN<input value={f.demandeur_cin} onChange={set('demandeur_cin')} /></label>
        <label>Téléphone<input value={f.demandeur_telephone} onChange={set('demandeur_telephone')} /></label>
        <label className="span2">Email<input type="email" value={f.demandeur_email} onChange={set('demandeur_email')} /></label>
      </div>
      <div className="actions"><button type="button" className="btn ghost" onClick={() => nav(-1)}>Annuler</button><button className="btn primary">Enregistrer</button></div>
    </form>
  </>);
}
