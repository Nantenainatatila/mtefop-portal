import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
const vide = { matricule: '', nom: '', prenom: '', email: '', mot_de_passe: '', role: 'agent', service_id: '' };
export default function Utilisateurs() {
  const [rows, setRows] = useState([]); const [services, setServices] = useState([]); const [f, setF] = useState(vide); const [msg, setMsg] = useState('');
  const load = () => api.get('/utilisateurs').then((r) => setRows(r.data));
  useEffect(() => { load(); api.get('/services').then((r) => setServices(r.data)); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const add = async (e) => { e.preventDefault(); try { await api.post('/utilisateurs', f); setF(vide); setMsg('Utilisateur créé'); load(); } catch (e) { setMsg(errMsg(e)); } };
  return (<>
    <h1>Utilisateurs</h1>
    <form className="card form" onSubmit={add}><h3>Nouvel utilisateur</h3>{msg && <div className="alert info">{msg}</div>}
      <div className="fgrid three">
        <label>Matricule<input value={f.matricule} onChange={set('matricule')} /></label>
        <label>Nom *<input required value={f.nom} onChange={set('nom')} /></label>
        <label>Prénom<input value={f.prenom} onChange={set('prenom')} /></label>
        <label>Email *<input type="email" required value={f.email} onChange={set('email')} /></label>
        <label>Mot de passe *<input type="password" minLength="6" required value={f.mot_de_passe} onChange={set('mot_de_passe')} /></label>
        <label>Rôle<select value={f.role} onChange={set('role')}><option value="agent">Agent</option><option value="admin">Administrateur</option><option value="consultation">Consultation</option></select></label>
        <label>Service<select value={f.service_id} onChange={set('service_id')}><option value="">—</option>{services.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}</select></label>
      </div><div className="actions"><button className="btn primary">Créer</button></div></form>
    <div className="card"><table><thead><tr><th>Matricule</th><th>Nom</th><th>Email</th><th>Rôle</th><th>Service</th><th>État</th><th></th></tr></thead>
      <tbody>{rows.map((u) => <tr key={u.id}><td>{u.matricule}</td><td>{u.nom} {u.prenom}</td><td>{u.email}</td><td>{u.role}</td><td>{u.service_nom}</td>
        <td>{u.actif ? <span className="badge b-valide">Actif</span> : <span className="badge b-rejete">Inactif</span>}</td>
        <td><button className="btn ghost sm" onClick={() => api.patch(`/utilisateurs/${u.id}/actif`).then(load)}>{u.actif ? 'Désactiver' : 'Activer'}</button></td></tr>)}</tbody></table></div>
  </>);
}
