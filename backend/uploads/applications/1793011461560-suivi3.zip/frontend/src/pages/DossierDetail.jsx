import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { API_URL, STATUTS, PRIORITES, fmt, fmtDT, errMsg } from '../api';
import { Badge } from '../components/Layout';
export const Timeline = ({ items }) => (
  <ul className="timeline">{items.map((h, i) => <li key={i}>
    <div className="dot" /><div><strong>{h.action}</strong>{h.statut && <> · <Badge s={h.statut} /></>}
      {(h.source_nom || h.dest_nom) && <p>{h.source_nom ? `${h.source_nom} → ` : '→ '}{h.dest_nom}</p>}
      {h.commentaire && <p className="muted">{h.commentaire}</p>}
      <small>{fmtDT(h.date_action)}{h.utilisateur_nom ? ` · ${h.utilisateur_nom}` : ''}</small></div></li>)}</ul>
);
export default function DossierDetail() {
  const { id } = useParams(); const nav = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));
  const [d, setD] = useState(null); const [services, setServices] = useState([]); const [msg, setMsg] = useState('');
  const [tr, setTr] = useState({ service_dest_id: '', commentaire: '' }); const [st, setSt] = useState({ statut: 'en_cours', commentaire: '' });
  const load = () => api.get(`/dossiers/${id}`).then((r) => setD(r.data));
  useEffect(() => { load(); api.get('/services').then((r) => setServices(r.data)); }, [id]);
  const run = async (fn, ok) => { try { await fn(); setMsg(ok); load(); } catch (e) { setMsg(errMsg(e)); } };
  if (!d) return <p>Chargement…</p>;
  const canEdit = user.role !== 'consultation';
  const upload = (e) => { const fd = new FormData(); fd.append('fichier', e.target.files[0]); run(() => api.post(`/dossiers/${id}/pieces`, fd), 'Pièce jointe ajoutée'); e.target.value = ''; };
  return (<>
    <div className="row-between"><div><Link to="/dossiers" className="muted">← Dossiers</Link><h1>{d.numero}</h1></div>
      <div className="actions">{canEdit && <Link className="btn ghost" to={`/dossiers/${id}/modifier`}>Modifier</Link>}
        {user.role === 'admin' && <button className="btn danger" onClick={() => confirm('Supprimer ce dossier ?') && api.delete(`/dossiers/${id}`).then(() => nav('/dossiers'))}>Supprimer</button>}
        <button className="btn ghost" onClick={() => window.print()}>Imprimer</button></div></div>
    {msg && <div className="alert info" onClick={() => setMsg('')}>{msg}</div>}
    <div className="grid2">
      <div className="card"><h3>{d.objet} <Badge s={d.statut} /></h3>
        <dl className="dl">
          <dt>Type</dt><dd>{d.type_libelle || '—'}</dd><dt>Priorité</dt><dd>{PRIORITES[d.priorite]}</dd>
          <dt>Service actuel</dt><dd>{d.service_nom || '—'}</dd><dt>Date de dépôt</dt><dd>{fmt(d.date_depot)}</dd>
          <dt>Échéance</dt><dd>{fmt(d.date_echeance)}</dd><dt>Enregistré par</dt><dd>{d.cree_par_nom}</dd>
          <dt>Demandeur</dt><dd>{d.demandeur_nom}</dd><dt>Matricule</dt><dd>{d.demandeur_matricule || '—'}</dd>
          <dt>CIN</dt><dd>{d.demandeur_cin || '—'}</dd><dt>Contact</dt><dd>{d.demandeur_telephone || '—'} {d.demandeur_email}</dd>
        </dl>
        {d.description && <p className="desc">{d.description}</p>}
        <h3>Pièces jointes</h3>
        <ul className="files">{d.pieces.map((p) => <li key={p.id}><a href={`${API_URL.replace('/api', '')}/uploads/${p.fichier}`} target="_blank">{p.nom_original}</a> <small>{Math.round(p.taille / 1024)} Ko</small></li>)}
          {!d.pieces.length && <li className="muted">Aucune pièce</li>}</ul>
        {canEdit && <label className="btn ghost">Ajouter une pièce<input type="file" hidden onChange={upload} /></label>}
      </div>
      <div>
        {canEdit && <>
          <div className="card"><h3>Transférer le dossier</h3>
            <select value={tr.service_dest_id} onChange={(e) => setTr({ ...tr, service_dest_id: e.target.value })}><option value="">Choisir un service</option>{services.filter((s) => s.id !== d.service_actuel_id).map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}</select>
            <textarea placeholder="Commentaire / instructions" value={tr.commentaire} onChange={(e) => setTr({ ...tr, commentaire: e.target.value })} />
            <button className="btn primary" disabled={!tr.service_dest_id} onClick={() => run(() => api.post(`/dossiers/${id}/transferer`, tr), 'Dossier transféré').then(() => setTr({ service_dest_id: '', commentaire: '' }))}>Transférer</button></div>
          <div className="card"><h3>Changer le statut</h3>
            <select value={st.statut} onChange={(e) => setSt({ ...st, statut: e.target.value })}>{Object.entries(STATUTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
            <textarea placeholder="Motif / observation" value={st.commentaire} onChange={(e) => setSt({ ...st, commentaire: e.target.value })} />
            <button className="btn primary" onClick={() => run(() => api.post(`/dossiers/${id}/statut`, st), 'Statut mis à jour')}>Mettre à jour</button></div></>}
        <div className="card"><h3>Historique du dossier</h3><Timeline items={d.historique} /></div>
      </div>
    </div>
  </>);
}
