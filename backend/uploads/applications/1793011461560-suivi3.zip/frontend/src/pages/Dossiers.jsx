import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { STATUTS, PRIORITES, fmt } from '../api';
import { Badge } from '../components/Layout';
export default function Dossiers() {
  const [rows, setRows] = useState([]); const [services, setServices] = useState([]); const [types, setTypes] = useState([]);
  const [f, setF] = useState({ q: '', statut: '', service_id: '', type_id: '' });
  const load = () => api.get('/dossiers', { params: f }).then((r) => setRows(r.data));
  useEffect(() => { api.get('/services').then((r) => setServices(r.data)); api.get('/types').then((r) => setTypes(r.data)); }, []);
  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [f]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const today = new Date().toISOString().slice(0, 10);
  return (<>
    <div className="row-between"><h1>Dossiers</h1><Link className="btn primary" to="/dossiers/nouveau">+ Nouveau dossier</Link></div>
    <div className="card filters">
      <input placeholder="Rechercher : numéro, objet, demandeur, matricule…" value={f.q} onChange={set('q')} />
      <select value={f.statut} onChange={set('statut')}><option value="">Tous statuts</option>{Object.entries(STATUTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <select value={f.service_id} onChange={set('service_id')}><option value="">Tous services</option>{services.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}</select>
      <select value={f.type_id} onChange={set('type_id')}><option value="">Tous types</option>{types.map((t) => <option key={t.id} value={t.id}>{t.libelle}</option>)}</select>
    </div>
    <div className="card"><table>
      <thead><tr><th>Numéro</th><th>Objet</th><th>Type</th><th>Demandeur</th><th>Service actuel</th><th>Priorité</th><th>Échéance</th><th>Statut</th></tr></thead>
      <tbody>{rows.map((d) => <tr key={d.id}>
        <td><Link to={`/dossiers/${d.id}`}>{d.numero}</Link></td><td>{d.objet}</td><td>{d.type_libelle}</td><td>{d.demandeur_nom}</td>
        <td>{d.service_code}</td><td><span className={`prio p-${d.priorite}`}>{PRIORITES[d.priorite]}</span></td>
        <td className={d.date_echeance < today && !['valide', 'rejete', 'cloture'].includes(d.statut) ? 'late' : ''}>{fmt(d.date_echeance)}</td>
        <td><Badge s={d.statut} /></td></tr>)}
        {!rows.length && <tr><td colSpan="8" className="muted center">Aucun dossier trouvé</td></tr>}</tbody>
    </table></div>
  </>);
}
