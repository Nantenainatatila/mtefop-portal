import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
export default function Services() {
  const [services, setServices] = useState([]); const [types, setTypes] = useState([]);
  const [s, setS] = useState({ code: '', nom: '', description: '' }); const [t, setT] = useState({ libelle: '', delai_jours: 30 }); const [msg, setMsg] = useState('');
  const load = () => { api.get('/services').then((r) => setServices(r.data)); api.get('/types').then((r) => setTypes(r.data)); };
  useEffect(load, []);
  const run = async (e, fn) => { e.preventDefault(); try { await fn(); load(); setMsg('Enregistré'); } catch (er) { setMsg(errMsg(er)); } };
  return (<>
    <h1>Services & types de dossier</h1>{msg && <div className="alert info">{msg}</div>}
    <div className="grid2">
      <div className="card"><h3>Services / directions</h3>
        <form className="inline" onSubmit={(e) => run(e, () => api.post('/services', s).then(() => setS({ code: '', nom: '', description: '' })))}>
          <input required placeholder="Code" value={s.code} onChange={(e) => setS({ ...s, code: e.target.value })} />
          <input required placeholder="Nom" value={s.nom} onChange={(e) => setS({ ...s, nom: e.target.value })} /><button className="btn primary">Ajouter</button></form>
        <table><tbody>{services.map((x) => <tr key={x.id}><td><b>{x.code}</b></td><td>{x.nom}</td><td><button className="btn danger sm" onClick={() => confirm('Supprimer ?') && api.delete(`/services/${x.id}`).then(load)}>×</button></td></tr>)}</tbody></table></div>
      <div className="card"><h3>Types de dossier</h3>
        <form className="inline" onSubmit={(e) => run(e, () => api.post('/types', t).then(() => setT({ libelle: '', delai_jours: 30 })))}>
          <input required placeholder="Libellé" value={t.libelle} onChange={(e) => setT({ ...t, libelle: e.target.value })} />
          <input type="number" placeholder="Délai (j)" value={t.delai_jours} onChange={(e) => setT({ ...t, delai_jours: e.target.value })} /><button className="btn primary">Ajouter</button></form>
        <table><tbody>{types.map((x) => <tr key={x.id}><td>{x.libelle}</td><td>{x.delai_jours} jours</td></tr>)}</tbody></table></div>
    </div>
  </>);
}
