import { useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmt } from '../api';
import { Badge, Logo } from '../components/Layout';
import { Timeline } from './DossierDetail';
export default function Suivi() {
  const [num, setNum] = useState(''); const [d, setD] = useState(null); const [err, setErr] = useState('');
  const go = async (e) => { e.preventDefault(); setErr(''); setD(null); try { setD((await api.get(`/dossiers/suivi/${num.trim()}`)).data); } catch (e) { setErr(errMsg(e)); } };
  return (
    <div className="public">
      <header className="public-head"><Logo /><Link to="/login" className="btn light">Espace agent</Link></header>
      <section className="public-hero"><h1>Suivez votre dossier en ligne</h1><p>Saisissez le numéro reçu lors du dépôt (ex : MTEFOP-2026-00001).</p>
        <form onSubmit={go} className="search"><input required value={num} onChange={(e) => setNum(e.target.value)} placeholder="Numéro du dossier" /><button className="btn primary">Rechercher</button></form></section>
      <div className="public-body">
        {err && <div className="alert">{err}</div>}
        {d && <div className="card"><div className="row-between"><h2>{d.numero}</h2><Badge s={d.statut} /></div>
          <dl className="dl"><dt>Objet</dt><dd>{d.objet}</dd><dt>Type</dt><dd>{d.type_libelle || '—'}</dd><dt>Déposé le</dt><dd>{fmt(d.date_depot)}</dd><dt>Se trouve actuellement à</dt><dd>{d.service_nom}</dd></dl>
          <h3>Parcours du dossier</h3><Timeline items={d.historique} /></div>}
      </div>
    </div>
  );
}
