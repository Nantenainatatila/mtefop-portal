import { NavLink, useNavigate } from 'react-router-dom';
export const Badge = ({ s }) => <span className={`badge b-${s}`}>{({ recu: 'Reçu', en_cours: 'En cours', en_attente: 'En attente', valide: 'Validé', rejete: 'Rejeté', cloture: 'Clôturé' })[s] || s}</span>;
export const Logo = () => (
  <div className="logo"><div className="logo-mark">M</div><div><strong>MTEFoP</strong><small>Suivi des dossiers</small></div></div>
);
export default function Layout({ user, children }) {
  const nav = useNavigate();
  const logout = () => { localStorage.clear(); nav('/login'); };
  return (
    <div className="app">
      <aside className="sidebar">
        <Logo />
        <nav>
          <NavLink to="/" end>Tableau de bord</NavLink>
          <NavLink to="/dossiers" end>Dossiers</NavLink>
          {user.role !== 'consultation' && <NavLink to="/dossiers/nouveau">Nouveau dossier</NavLink>}
          <NavLink to="/suivi">Suivi public</NavLink>
          {user.role === 'admin' && <><div className="nav-title">Administration</div>
            <NavLink to="/utilisateurs">Utilisateurs</NavLink><NavLink to="/services">Services & types</NavLink></>}
        </nav>
        <div className="sidebar-foot">Repoblikan'i Madagasikara<br />Fitiavana – Tanindrazana – Fandrosoana</div>
      </aside>
      <div className="main">
        <header className="topbar">
          <span>Ministère du Travail, de l'Emploi et de la Fonction Publique</span>
          <div className="user"><span>{user.nom} {user.prenom} · <em>{user.role}</em></span><button className="btn ghost" onClick={logout}>Déconnexion</button></div>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  );
}
