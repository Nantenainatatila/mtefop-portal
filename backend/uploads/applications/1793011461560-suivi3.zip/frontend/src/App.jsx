import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Dossiers from './pages/Dossiers';
import DossierForm from './pages/DossierForm';
import DossierDetail from './pages/DossierDetail';
import Suivi from './pages/Suivi';
import Utilisateurs from './pages/Utilisateurs';
import Services from './pages/Services';

const Private = ({ children, admin }) => {
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  if (!user) return <Navigate to="/login" />;
  if (admin && user.role !== 'admin') return <Navigate to="/" />;
  return <Layout user={user}>{children}</Layout>;
};

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/suivi" element={<Suivi />} />
      <Route path="/" element={<Private><Dashboard /></Private>} />
      <Route path="/dossiers" element={<Private><Dossiers /></Private>} />
      <Route path="/dossiers/nouveau" element={<Private><DossierForm /></Private>} />
      <Route path="/dossiers/:id/modifier" element={<Private><DossierForm /></Private>} />
      <Route path="/dossiers/:id" element={<Private><DossierDetail /></Private>} />
      <Route path="/utilisateurs" element={<Private admin><Utilisateurs /></Private>} />
      <Route path="/services" element={<Private admin><Services /></Private>} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
