import axios from 'axios';
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const api = axios.create({ baseURL: API_URL });
api.interceptors.request.use((c) => { const t = localStorage.getItem('token'); if (t) c.headers.Authorization = `Bearer ${t}`; return c; });
api.interceptors.response.use((r) => r, (e) => {
  if (e.response?.status === 401 && localStorage.getItem('token')) { localStorage.clear(); window.location.href = '/login'; }
  return Promise.reject(e);
});
export const errMsg = (e) => e.response?.data?.message || 'Une erreur est survenue';
export const STATUTS = { recu: 'Reçu', en_cours: 'En cours', en_attente: 'En attente', valide: 'Validé', rejete: 'Rejeté', cloture: 'Clôturé' };
export const PRIORITES = { normale: 'Normale', urgente: 'Urgente', tres_urgente: 'Très urgente' };
export const fmt = (d) => d ? new Date(d.replace(' ', 'T')).toLocaleDateString('fr-FR') : '—';
export const fmtDT = (d) => d ? new Date(d.replace(' ', 'T')).toLocaleString('fr-FR') : '—';
export default api;
