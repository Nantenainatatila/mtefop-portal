--
-- PostgreSQL database dump
--

\restrict xXoa8RKXuecAa785GTCy4aC2vxSF7oy3T7g7SEVHy5HcUMhjTE2kWSpnIOQWEDD

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

-- Started on 2026-09-02 12:07:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 32971)
-- Name: annee_scolaire; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annee_scolaire (
    id_annee integer NOT NULL,
    annee character varying(9) NOT NULL
);


ALTER TABLE public.annee_scolaire OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 32970)
-- Name: annee_scolaire_id_annee_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.annee_scolaire_id_annee_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.annee_scolaire_id_annee_seq OWNER TO postgres;

--
-- TOC entry 5024 (class 0 OID 0)
-- Dependencies: 221
-- Name: annee_scolaire_id_annee_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.annee_scolaire_id_annee_seq OWNED BY public.annee_scolaire.id_annee;


--
-- TOC entry 220 (class 1259 OID 32962)
-- Name: etudiants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etudiants (
    id_etudiant integer NOT NULL,
    nom character varying(50) NOT NULL,
    prenom character varying(50),
    adresse character varying(100),
    date_naissance date,
    telephone character varying(20),
    matricule character varying(20),
    lieu_naissance character varying(100)
);


ALTER TABLE public.etudiants OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 32961)
-- Name: etudiants_id_etudiant_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etudiants_id_etudiant_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etudiants_id_etudiant_seq OWNER TO postgres;

--
-- TOC entry 5025 (class 0 OID 0)
-- Dependencies: 219
-- Name: etudiants_id_etudiant_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etudiants_id_etudiant_seq OWNED BY public.etudiants.id_etudiant;


--
-- TOC entry 230 (class 1259 OID 33010)
-- Name: inscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inscriptions (
    id_inscription integer NOT NULL,
    id_etudiant integer NOT NULL,
    id_annee integer NOT NULL,
    id_mention integer NOT NULL,
    id_niveau integer NOT NULL
);


ALTER TABLE public.inscriptions OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 33009)
-- Name: inscriptions_id_inscription_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inscriptions_id_inscription_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inscriptions_id_inscription_seq OWNER TO postgres;

--
-- TOC entry 5026 (class 0 OID 0)
-- Dependencies: 229
-- Name: inscriptions_id_inscription_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inscriptions_id_inscription_seq OWNED BY public.inscriptions.id_inscription;


--
-- TOC entry 228 (class 1259 OID 33000)
-- Name: matieres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matieres (
    id_matiere integer NOT NULL,
    nom_matiere character varying(100) NOT NULL,
    coefficient integer NOT NULL
);


ALTER TABLE public.matieres OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 32999)
-- Name: matieres_id_matiere_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.matieres_id_matiere_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.matieres_id_matiere_seq OWNER TO postgres;

--
-- TOC entry 5027 (class 0 OID 0)
-- Dependencies: 227
-- Name: matieres_id_matiere_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.matieres_id_matiere_seq OWNED BY public.matieres.id_matiere;


--
-- TOC entry 235 (class 1259 OID 33119)
-- Name: matricule_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.matricule_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.matricule_seq OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 33042)
-- Name: mention_matiere; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mention_matiere (
    id_mention_matiere integer NOT NULL,
    id_mention integer NOT NULL,
    id_matiere integer NOT NULL
);


ALTER TABLE public.mention_matiere OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 33041)
-- Name: mention_matiere_id_mention_matiere_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mention_matiere_id_mention_matiere_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mention_matiere_id_mention_matiere_seq OWNER TO postgres;

--
-- TOC entry 5028 (class 0 OID 0)
-- Dependencies: 231
-- Name: mention_matiere_id_mention_matiere_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mention_matiere_id_mention_matiere_seq OWNED BY public.mention_matiere.id_mention_matiere;


--
-- TOC entry 226 (class 1259 OID 32991)
-- Name: mentions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentions (
    id_mention integer NOT NULL,
    nom_mention character varying(100) NOT NULL
);


ALTER TABLE public.mentions OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 32990)
-- Name: mentions_id_mention_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mentions_id_mention_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mentions_id_mention_seq OWNER TO postgres;

--
-- TOC entry 5029 (class 0 OID 0)
-- Dependencies: 225
-- Name: mentions_id_mention_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mentions_id_mention_seq OWNED BY public.mentions.id_mention;


--
-- TOC entry 224 (class 1259 OID 32982)
-- Name: niveaux; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.niveaux (
    id_niveau integer NOT NULL,
    niveau character varying(50) NOT NULL
);


ALTER TABLE public.niveaux OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 32981)
-- Name: niveaux_id_niveau_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.niveaux_id_niveau_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.niveaux_id_niveau_seq OWNER TO postgres;

--
-- TOC entry 5030 (class 0 OID 0)
-- Dependencies: 223
-- Name: niveaux_id_niveau_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.niveaux_id_niveau_seq OWNED BY public.niveaux.id_niveau;


--
-- TOC entry 234 (class 1259 OID 33062)
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes (
    id_note integer NOT NULL,
    id_inscription integer NOT NULL,
    id_matiere integer NOT NULL,
    note numeric(5,2),
    id_type_examen integer
);


ALTER TABLE public.notes OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 33061)
-- Name: notes_id_note_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notes_id_note_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notes_id_note_seq OWNER TO postgres;

--
-- TOC entry 5031 (class 0 OID 0)
-- Dependencies: 233
-- Name: notes_id_note_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notes_id_note_seq OWNED BY public.notes.id_note;


--
-- TOC entry 237 (class 1259 OID 33182)
-- Name: types_examen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.types_examen (
    id_type_examen integer NOT NULL,
    type_examen character varying(100) NOT NULL
);


ALTER TABLE public.types_examen OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 33181)
-- Name: types_examen_id_type_examen_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.types_examen_id_type_examen_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.types_examen_id_type_examen_seq OWNER TO postgres;

--
-- TOC entry 5032 (class 0 OID 0)
-- Dependencies: 236
-- Name: types_examen_id_type_examen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.types_examen_id_type_examen_seq OWNED BY public.types_examen.id_type_examen;


--
-- TOC entry 239 (class 1259 OID 33218)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user integer NOT NULL,
    name_user character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'admin'::character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 33217)
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_user_seq OWNER TO postgres;

--
-- TOC entry 5033 (class 0 OID 0)
-- Dependencies: 238
-- Name: users_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_user_seq OWNED BY public.users.id_user;


--
-- TOC entry 4802 (class 2604 OID 32974)
-- Name: annee_scolaire id_annee; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annee_scolaire ALTER COLUMN id_annee SET DEFAULT nextval('public.annee_scolaire_id_annee_seq'::regclass);


--
-- TOC entry 4801 (class 2604 OID 32965)
-- Name: etudiants id_etudiant; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etudiants ALTER COLUMN id_etudiant SET DEFAULT nextval('public.etudiants_id_etudiant_seq'::regclass);


--
-- TOC entry 4806 (class 2604 OID 33013)
-- Name: inscriptions id_inscription; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions ALTER COLUMN id_inscription SET DEFAULT nextval('public.inscriptions_id_inscription_seq'::regclass);


--
-- TOC entry 4805 (class 2604 OID 33003)
-- Name: matieres id_matiere; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id_matiere SET DEFAULT nextval('public.matieres_id_matiere_seq'::regclass);


--
-- TOC entry 4807 (class 2604 OID 33045)
-- Name: mention_matiere id_mention_matiere; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mention_matiere ALTER COLUMN id_mention_matiere SET DEFAULT nextval('public.mention_matiere_id_mention_matiere_seq'::regclass);


--
-- TOC entry 4804 (class 2604 OID 32994)
-- Name: mentions id_mention; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions ALTER COLUMN id_mention SET DEFAULT nextval('public.mentions_id_mention_seq'::regclass);


--
-- TOC entry 4803 (class 2604 OID 32985)
-- Name: niveaux id_niveau; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveaux ALTER COLUMN id_niveau SET DEFAULT nextval('public.niveaux_id_niveau_seq'::regclass);


--
-- TOC entry 4808 (class 2604 OID 33065)
-- Name: notes id_note; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes ALTER COLUMN id_note SET DEFAULT nextval('public.notes_id_note_seq'::regclass);


--
-- TOC entry 4809 (class 2604 OID 33185)
-- Name: types_examen id_type_examen; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types_examen ALTER COLUMN id_type_examen SET DEFAULT nextval('public.types_examen_id_type_examen_seq'::regclass);


--
-- TOC entry 4810 (class 2604 OID 33221)
-- Name: users id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id_user SET DEFAULT nextval('public.users_id_user_seq'::regclass);


--
-- TOC entry 4819 (class 2606 OID 32980)
-- Name: annee_scolaire annee_scolaire_annee_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annee_scolaire
    ADD CONSTRAINT annee_scolaire_annee_key UNIQUE (annee);


--
-- TOC entry 4821 (class 2606 OID 32978)
-- Name: annee_scolaire annee_scolaire_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annee_scolaire
    ADD CONSTRAINT annee_scolaire_pkey PRIMARY KEY (id_annee);


--
-- TOC entry 4813 (class 2606 OID 33118)
-- Name: etudiants etudiants_matricule_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etudiants
    ADD CONSTRAINT etudiants_matricule_key UNIQUE (matricule);


--
-- TOC entry 4815 (class 2606 OID 32969)
-- Name: etudiants etudiants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etudiants
    ADD CONSTRAINT etudiants_pkey PRIMARY KEY (id_etudiant);


--
-- TOC entry 4829 (class 2606 OID 33020)
-- Name: inscriptions inscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions
    ADD CONSTRAINT inscriptions_pkey PRIMARY KEY (id_inscription);


--
-- TOC entry 4827 (class 2606 OID 33008)
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id_matiere);


--
-- TOC entry 4831 (class 2606 OID 33050)
-- Name: mention_matiere mention_matiere_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mention_matiere
    ADD CONSTRAINT mention_matiere_pkey PRIMARY KEY (id_mention_matiere);


--
-- TOC entry 4825 (class 2606 OID 32998)
-- Name: mentions mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_pkey PRIMARY KEY (id_mention);


--
-- TOC entry 4823 (class 2606 OID 32989)
-- Name: niveaux niveaux_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveaux
    ADD CONSTRAINT niveaux_pkey PRIMARY KEY (id_niveau);


--
-- TOC entry 4833 (class 2606 OID 33070)
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id_note);


--
-- TOC entry 4837 (class 2606 OID 33190)
-- Name: types_examen types_examen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types_examen
    ADD CONSTRAINT types_examen_pkey PRIMARY KEY (id_type_examen);


--
-- TOC entry 4817 (class 2606 OID 33131)
-- Name: etudiants unique_nom_prenom; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etudiants
    ADD CONSTRAINT unique_nom_prenom UNIQUE (nom, prenom);


--
-- TOC entry 4835 (class 2606 OID 33212)
-- Name: notes unique_note; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT unique_note UNIQUE (id_matiere, id_inscription, id_type_examen);


--
-- TOC entry 4839 (class 2606 OID 33232)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4841 (class 2606 OID 33230)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- TOC entry 4842 (class 2606 OID 33026)
-- Name: inscriptions fk_annee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions
    ADD CONSTRAINT fk_annee FOREIGN KEY (id_annee) REFERENCES public.annee_scolaire(id_annee) ON DELETE CASCADE;


--
-- TOC entry 4843 (class 2606 OID 33021)
-- Name: inscriptions fk_etudiant; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions
    ADD CONSTRAINT fk_etudiant FOREIGN KEY (id_etudiant) REFERENCES public.etudiants(id_etudiant) ON DELETE CASCADE;


--
-- TOC entry 4844 (class 2606 OID 33031)
-- Name: inscriptions fk_mention; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions
    ADD CONSTRAINT fk_mention FOREIGN KEY (id_mention) REFERENCES public.mentions(id_mention) ON DELETE CASCADE;


--
-- TOC entry 4846 (class 2606 OID 33056)
-- Name: mention_matiere fk_mm_matiere; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mention_matiere
    ADD CONSTRAINT fk_mm_matiere FOREIGN KEY (id_matiere) REFERENCES public.matieres(id_matiere) ON DELETE CASCADE;


--
-- TOC entry 4847 (class 2606 OID 33051)
-- Name: mention_matiere fk_mm_mention; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mention_matiere
    ADD CONSTRAINT fk_mm_mention FOREIGN KEY (id_mention) REFERENCES public.mentions(id_mention) ON DELETE CASCADE;


--
-- TOC entry 4845 (class 2606 OID 33036)
-- Name: inscriptions fk_niveau; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscriptions
    ADD CONSTRAINT fk_niveau FOREIGN KEY (id_niveau) REFERENCES public.niveaux(id_niveau) ON DELETE CASCADE;


--
-- TOC entry 4848 (class 2606 OID 33071)
-- Name: notes fk_note_inscription; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT fk_note_inscription FOREIGN KEY (id_inscription) REFERENCES public.inscriptions(id_inscription) ON DELETE CASCADE;


--
-- TOC entry 4849 (class 2606 OID 33076)
-- Name: notes fk_note_matiere; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT fk_note_matiere FOREIGN KEY (id_matiere) REFERENCES public.matieres(id_matiere) ON DELETE CASCADE;


--
-- TOC entry 4850 (class 2606 OID 33198)
-- Name: notes fk_notes_types_examen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT fk_notes_types_examen FOREIGN KEY (id_type_examen) REFERENCES public.types_examen(id_type_examen) ON DELETE CASCADE;


-- Completed on 2026-09-02 12:07:40

--
-- PostgreSQL database dump complete
--

\unrestrict xXoa8RKXuecAa785GTCy4aC2vxSF7oy3T7g7SEVHy5HcUMhjTE2kWSpnIOQWEDD

