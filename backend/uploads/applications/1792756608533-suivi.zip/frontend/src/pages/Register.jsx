import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import api, { errMsg } from '../api';

export default function Register() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const [services, setServices] = useState([]);
  const [f, setF] = useState({
    matricule: '', nom: '', prenom: '', email: '', telephone: '',
    service_id: '', mot_de_passe: '', confirmation: '',
  });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get('/auth/services').then((r) => setServices(r.data)).catch(() => setError('Impossible de charger la liste des services'));
  }, []);

  if (user) return <Navigate to="/" replace />;

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (f.mot_de_passe.length < 8) return setError('Le mot de passe doit contenir 8 caractères minimum');
    if (f.mot_de_passe !== f.confirmation) return setError('Les mots de passe ne correspondent pas');
    setBusy(true);
    try {
      const { confirmation, ...payload } = f;
      await api.post('/auth/register', payload);
      await login(f.email.trim().toLowerCase(), f.mot_de_passe);
      nav('/');
    } catch (err) { setError(errMsg(err)); }
    finally { setBusy(false); }
  };

  return (
    <div className="login-page">
      <form className="login-card wide" onSubmit={submit}>
        <div className="logo big">M</div>
        <h1>Création de compte</h1>
        <p className="muted">Ministère du Travail, de l'Emploi et de la Fonction Publique<br />Système de suivi des dossiers</p>
        {error && <div className="alert alert-error">{error}</div>}
        <label>Matricule *
          <input value={f.matricule} onChange={set('matricule')} required autoFocus />
        </label>
        <label>Nom *
          <input value={f.nom} onChange={set('nom')} required />
        </label>
        <label>Prénom
          <input value={f.prenom} onChange={set('prenom')} />
        </label>
        <label>Adresse e-mail *
          <input type="email" value={f.email} onChange={set('email')} required />
        </label>
        <label>Téléphone
          <input type="tel" value={f.telephone} onChange={set('telephone')} />
        </label>
        <label>Service *
          <select value={f.service_id} onChange={set('service_id')} required>
            <option value="">— Choisir un service —</option>
            {services.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}
          </select>
        </label>
        <label>Mot de passe * (8 caractères minimum)
          <input type="password" value={f.mot_de_passe} onChange={set('mot_de_passe')} required minLength={8} autoComplete="new-password" />
        </label>
        <label>Confirmer le mot de passe *
          <input type="password" value={f.confirmation} onChange={set('confirmation')} required minLength={8} autoComplete="new-password" />
        </label>
        <button className="btn btn-primary" disabled={busy}>{busy ? 'Création…' : 'Créer mon compte'}</button>
        <p className="center">Déjà un compte ? <Link to="/login">Se connecter</Link></p>
      </form>
    </div>
  );
}
