// src/data/projects.js
export const projects = [
    {
      title: "Car_Mada",
      description: "Plateforme e-commerce des ventes et d'achats des voitures suivi par l'administrateur",
      tech: ["HTML","CSS","React", "Node.js", "PostgreSQL"],
      link: "https://github.com/Nantenainatatila/gestion_ecole",
      image: "image1project1.webp"
    },
    {
      title: "Gestion des notes",
      description: "Ce projet sert à gérer tous les notes de l'école avec calcules des moyennes automatiques, les observations aisi que la generation automatique des listes pour chaque resultats et un relevé des notes pour chaque étudiant en pdf",
      tech: ["HTML","CSS","React", "Node.js", "PostgreSQL"],
      link: "https://github.com/Nantenainatatila/gestion_ecole",
      image: "image1project2.web"
    },
    {
      title: "Gestion des commandes",
      description: "Ce projet sert à commander des produits en ligne et l'admin peut gérer ces commandes",
      tech: ["HTML","CSS", "Python (flask)", "PostgreSQL"],
      link: "https://github.com/Nantenainatatila",
      image: "image1project3.png"
    },
  ];


  