const { Pool } = require("pg");

const pool = new Pool({
    user:"postgres",
    host:"localhost",
    database:"gestion_notes_universite",
    password:"4515",
    port:"5432"
});
module.exports = pool;